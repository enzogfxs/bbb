document.getElementById('voteForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const selected = document.querySelector('input[name="vote"]:checked').value;
    alert("Você votou para eliminar: Robbb " + selected);
});
